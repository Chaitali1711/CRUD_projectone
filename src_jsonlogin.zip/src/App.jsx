import React, { Component } from "react";
// import {Routes,Route,BrowserRouter} from 'react-router-dom';
import NavBar from "./NavBar";
// import MainContent2 from "./MainContent2";
// import MainContent from "./MainContent";
// import Order from "./Order";
// import Cart  from "./Cart";
// import ShoppingCart from './ShoppingCart'
// import Shoppingcartfetch from "./Shoppingcartfetch";
import Login from "./Login";
// import RegistrationForm from "./RegistrationForm";
// import TravelForm from "./TravelForm";
// import Widgets from "./Widgets";
// import Pagination from "./Pagination";

// import Table from './Table'
export default class App extends Component {
  render() {
    return (
      <React.Fragment>
        <NavBar />
        {/* <Table /> */}
        {/* <MainContent2 /> */}
        {/* <MainContent /> */}
        {/* <Cart /> */}
        {/* <ShoppingCart/> */}
        {/* <Shoppingcartfetch/> */}
        <Login/>
        {/* <RegistrationForm/> */}
        {/* <TravelForm/> */}
        {/* <Widgets/> */}
        {/* <Pagination/> */}
      </React.Fragment>
      // <BrowserRouter>
      // <NavBar/>
      // {/* <Routes>
      //   <Route path="/" exact Component={Widgets}/>
      //   <Route path="/Login" Component={Login}/>
      //   <Route path="/RegistrationForm" Component={RegistrationForm}/>
      //   <Route path="/TravelForm" Component={TravelForm}/>
      // </Routes> */}
      //  <Routes>
      //   <Route path="/" exact element={<Widgets/>}/>
      //   <Route path="/Login" element={<Login/>}/>
      //   <Route path="/RegistrationForm" element={<RegistrationForm/>}/>
      //   <Route path="/TravelForm" element={<TravelForm />}/>
      // </Routes>
      // </BrowserRouter>

    );
  }
}
