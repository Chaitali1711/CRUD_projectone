import React, { Component } from "react"
import Order from "./Order";

export default class Products extends Component {

    state = {
        customer: [
        {
            id:1,
            name:"Ram",
            ContactNo: 1234567890
        },
        {
            id:2,
            name:"Sham",
            ContactNo: 45678895213
        },
        {
            id:3,
            name:"Ramesh",
            ContactNo: 1548965723
        },],
    };
    
    render() {
        return(
            <div>
                {this.state.customer.map((cust,index) => {
                    console.log(cust);
              return (
                  <div>
                      <Order/>
                  </div>
              );
            })}
            </div>
        );        
    }
}