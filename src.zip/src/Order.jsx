import React, { Component } from "react";
// import Products from './Products'

export default class Order extends Component{

    render() {
        return (
            <div>
              Orders1
            </div>
        );
    };
}
