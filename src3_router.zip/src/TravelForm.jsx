import React, { Component } from 'react';

export default class TravelForm extends Component {

    
render(){
    return(
        <div className='bg-dark text-white align-center d-flex justify-content-center '>
            <form className='form text-start m-5 w-50'>
                <h6 className='text-warning'>* Denotes Mandatory Field</h6>
                <div className='m-3'>
                    <label htmlFor='name'>Full Name: <span className='text-danger'>*</span></label>
                    <input type="text" value="" id="name" className='form-control' placeholder="Enter Your Full Name" required/>
                    <hr className='bg-light'/>
                </div>
                <div className='m-3'>
                    <label htmlFor='email'>Email Address: <span className='text-danger'>*</span></label>
                    <input type="text" value="" id="email" className='form-control' placeholder="Enter Your Email address" required/>
                    <hr className='bg-light'/>
                </div>
                <div className='m-3'>
                    <label htmlFor='package'>Select Your Tour Package <span className='text-danger'>*</span> </label>
                    <select className='form-control w-50'>
                        <option>GOA</option>
                        <option>MANALI</option>
                        <option>KONNOOR</option>
                    </select>
                    <hr className='bg-light'/>
                </div>
                <div className='m-3'>
                    <label htmlFor='arrivalDate'>Arrival Date: <span className='text-danger'>*</span></label>
                    <input type="date" value="" id="arrivalDate" className='form-control w-25' required/>
                    <hr className='bg-light'/>
                </div>
                <div className='m-3'>
                    <label htmlFor='persons'>Number of Persons: <span className='text-danger'>*</span></label>
                    <select className='w-25 form-control'>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                        <option>5</option>
                    </select>
                    <hr className='bg-light'/>
                </div>
                <div className='m-3'>
                    <label htmlFor='avail'>What Would You Want To Avail? <span className='text-danger'>* </span></label><br/>
                    Boarding :<input type="checkbox" value='' id="avail" checked/><br />
                    Fooding :<input type="checkbox" value='' id="avail" /><br/>
                    Site-Seeing :<input type="checkbox" value='' id="avail" /><br/>
                    Safari :<input type="checkbox" value='' id="avail" /><br/>
                    <hr className='bg-light'/>
                </div>
                <div className='m-3'>
                    <div className="mb-3">
                        <label htmlFor='id'>Select Any of The ID Proof :<span className='text-danger'>*</span></label>
                        <select className='w-25 form-control'>
                            <option>Adhar Card</option>
                            <option>Pan Card</option>
                            <option>Voter ID Card</option>
                            <option>Driving Liscense</option>
                        </select>
                    </div>
                    <input type="file"  />
                    <hr className='bg-light'/>
                </div>
                <div className='m-3'>
                    <label htmlFor='tnc'>Arrival Date: <span className='text-danger'>* &nbsp;</span></label>
                    <input type="radio" value="Agree" id="tnc" checked />&nbsp; I Agree &nbsp;
                    <input type="radio" value="Disagree" id="tnc" />&nbsp; I Diagree &nbsp;
                    <hr className='bg-light'/>
                </div>
                <div className='d-flex justify-content-center align-items-center'>
                <input type="submit" value="Confirm Reservation" />
                </div>

            </form>
        </div>
    )
}

}