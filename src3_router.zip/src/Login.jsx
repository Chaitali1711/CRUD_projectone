import React from 'react'

export default class Login extends React.Component{
    constructor(){
        super();
        this.state={
                    name:'',
                    passwd:''
        }
    }

    fnTextChange=(x)=>{
        this.setState({
            name:x.target.value
        })
    }

    fnPwdChange=(x)=>{
        this.setState({
            passwd:x.target.value
        })
    }

    fnSubmit=(x)=>{
console.log("Name:" +this.state.name +" Password: "+this.state.passwd)

    }

    render(){
        return(
            <div className='row align-items-center flex-column'>
                <form className='form '>
                    <div className='mb-3'>
                        <h2 className="text-center text-primary">LOGIN FORM</h2>
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="uname">Name</label>
                        <input type="text" id='uname' className='form-control' placeholder='Enter the username' value={this.state.name} onChange={this.fnTextChange}/>
                    </div>
                    <div className='mb-3'>
                        <label htmlFor="pwd" >Password</label>
                        <input type="password" id="pwd" className='form-control' placeholder='Enter the password' value={this.state.passwd} onChange={this.fnPwdChange}/>
                    </div>
                    <div className='mb-3 d-flex justify-content-center'>
                        <input type="button" value="Submit" className='mx-3' onClick={()=>{this.fnSubmit()}}/>
                        <input type="reset" value="Clear" className='mx-3' />
                    </div>                    
                </form>
            </div>
        );
    }

    
}
