import React , { Component } from "react";

export default class Pagination extends Component{

    constructor(){
        super();
        this.state={
            name:'',
            firstname:'',
            inquiry:''
        }
    }

    fnNameChange=(v)=>{this.setState({ name:v.target.value })};
    fnFnameChange=(v)=>{this.setState({ firstname:v.target.value })};
    fnTextarea=(v)=>{this.setState({ inquiry: v.target.value})}
    
    fnSubmit=(v)=>{
console.log(this.state.name + " "+ this.state.firstname)
console.log("Your message: "+this.state.inquiry)

    }

    render(){
        return(
            <div>
                <div className="d-flex flex-column align-items-center">
                    <div id="login" className=" ">
                        <div className="my-2 mx-5">
                            <h5 className="text-primary">LOGIN</h5>
                            <input type="text"  value={this.state.name} onChange={this.fnNameChange}/>
                        </div>
                        <div className="my-2 mx-5 d-flex">
                            <div className="mx-5">
                                <a href="#" className="btn disabled" aria-disabled="true" >Prev</a>
                            </div>
                            <div>
                                <a href="#registration" className="btn">Next</a>
                            </div>
                        </div>
                    </div>
                    <div id="registration" className="">
                        <div className="my-2 mx-5">
                            <h5 className="text-primary">Registration</h5>
                            <input type="text"  value={this.state.firstname} onChange={this.fnFnameChange}/>
                        </div>
                        <div className="my-2 mx-5 d-flex">
                            <div className="mx-5">
                                <a href="#login" className="btn">Prev</a>
                            </div>
                            <div>
                                <a href="#inquiry" className="btn">Next</a>
                            </div>
                        </div>
                    </div>
                    <div id="inquiry" className="">
                        <div className="my-2 mx-5">
                            <h5 className="text-primary">INQUIRY</h5>
                            <textarea value={this.state.name} placeholder="Give us your message" onChange={this.fnTextarea}/>
                        </div>
                        <div className="my-2 mx-5 d-flex">
                            <div className="mx-5">
                                <a href="#registration" className="btn">Prev</a>
                            </div>
                            <div>
                                <a href="#" className="btn disabled" >Next</a>
                            </div>
                        </div>
                    </div>
                        <button className="btn btn-warning" onClick={()=>this.fnSubmit()}>SUBMIT</button>
                </div>
                <nav>
                    <ul className="pagination justify-content-center">
                        <li className="page-item"><a className="page-link" href="#">Previous</a></li>
                        <li className="page-item"><a className="page-link" href="#login">Login</a></li>
                        <li className="page-item"><a className="page-link" href="#registration">Registration</a></li>
                        <li className="page-item"><a className="page-link" href="#inquiry">Inquiry</a></li>
                        <li className="page-item"><a className="page-link" href="#">Next</a></li>
                    </ul>
                </nav>
            </div>
        )
    }
}